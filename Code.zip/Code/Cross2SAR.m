function C3_Cross = Cross2SAR(csar,Azimuth,Nrg_lines_blk,y_step,Range,Range_block,x_step)

Cross_Cor = zeros(round((Azimuth-Nrg_lines_blk+1)/y_step),...
    round((Range-Range_block+1)/x_step));

j0 = 1;
for jj = 1:y_step:(Azimuth-Nrg_lines_blk+1) 
    i0 = 1;
    for ii = 1:x_step:(Range-Range_block+1)
        csar_block = csar(jj:(jj+Nrg_lines_blk-1),ii:(ii+Range_block-1));
        Cross_Cor(j0,i0) = Crossmetry(csar_block,Nrg_lines_blk);
        i0=i0+1;
    end
    j0=j0+1;
end
C3_Cross = Cross_Cor;