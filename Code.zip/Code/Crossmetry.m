function Cross_value = Crossmetry(csar_block,Nrg_lines_blk)
ph = mean(mean(csar_block(2:Nrg_lines_blk,:).*conj(csar_block(1:Nrg_lines_blk-1,:))));
Cross_value = ph;
end