%********************************************************************************************
% Polarimetric Autocorrelation (A3) Matrix Code Description                                 *
%                   input: S2 matrix                                                        *
%                   output: A series of matrices                                            *
%                           C3_Mean & A3 & A3_Cov & A3_Dop & q_coff                         *
%                                                                                           *
% Copyright:Xi Zhang;                                                                       *
% The First Institute of Oceanography, Ministry of Natural Resources of China.              *
% Email: xi.zhang@fio.org.cn                                                                *
%********************************************************************************************
clear; clc; close all;

%% ���ڼ�FFT��������
Nrg_lines_blk = 11; %33; %128;
Range_block = 11; %33; %64;
y_step = 1; %8;       %4 %2 %8
x_step = 1; %4;       %8 %4 %16
kernels = 4;          %Number of parallel cores
re_use = false;      % Does it reuse the results of previous processing? True for reuse, false if not.

%% File Path Configuration
SAR_dir_path = 'E:\2_DATA\RS2_quad_pol_data_with_S2_15\Hong_Kong\'; %SAR�ļ���·��
Pol_sign = ['s11';'s22';'s12']; %Ҫ����������
Output_dir_path = 'E:\2_DATA\RS2_quad_pol_data_with_S2_15\Hong_Kong\A3\';

%% Parameter loading
c = 299792458.0; % light speed
xml_file = [SAR_dir_path,'product.xml'];
[Radar_freq, PRF, t0, dop_coef, range, azimuth, range_spacing, azimuth_spacing, escending] = read_xml(xml_file);

%% Define the number of image
% whole image
def_first_line = 1;
def_last_line = azimuth;
def_first_sample = 1;
def_last_sample = range;

%% read SAR data
for ii = 1:length(Pol_sign)
    SAR_name(ii,:) = [SAR_dir_path, 'S\', Pol_sign(ii,:), '.bin'];
    hdr_name(ii,:) = [SAR_name(ii,:),'.hdr'];
    [SAR, info] = enviread_zx(SAR_name(ii,:), hdr_name(ii,:));
    csar(:,:,ii) = SAR;
    clear SAR info
end

%% Read data from a specified region
csar = csar(def_first_line:def_last_line,def_first_sample:def_last_sample,:);
[def_azimuth,def_sample] = size(csar(:,:,1));

%% Formation of K-vectors
k1 = csar(:,:,1);
k2 = csar(:,:,3)*2/sqrt(2);
k3 = csar(:,:,2);
clear csar

K(:,:,1) = k1;
K(:,:,2) = k2;
K(:,:,3) = k3;

K_No=[1, 1; 1, 2; 1, 3; 2, 1; 2, 2; 2, 3; 3, 1; 3, 2; 3, 3];

%% Calculate the C3 matrix
C3(:,:,1) = k1.*conj(k1);
C3(:,:,2) = k1.*conj(k2);
C3(:,:,3) = k1.*conj(k3);
C3(:,:,4) = k2.*conj(k1);
C3(:,:,5) = k2.*conj(k2);
C3(:,:,6) = k2.*conj(k3);
C3(:,:,7) = k3.*conj(k1);
C3(:,:,8) = k3.*conj(k2);
C3(:,:,9) = k3.*conj(k3);
clear k1 k2 k3;

%% Calculate C3_Mean matrix
if ~re_use
    p=parpool(kernels);
    tic
    parfor ii=1:length(K_No)
        ii
        C3_Mean(:,:,ii) = Mean2SAR(K(:,:,K_No(ii,1)),K(:,:,K_No(ii,2)),def_azimuth,Nrg_lines_blk,y_step,def_sample,Range_block,x_step);
    end
    toc
    delete(p);
    C3_Mean_trace = C3_Mean(:,:,1) + C3_Mean(:,:,5) + C3_Mean(:,:,9);
    save([Output_dir_path, 'C3_Mean.mat'], 'C3_Mean');
else
    load([Output_dir_path, 'C3_Mean.mat'], 'C3_Mean');
end

%% Calculate the autocorrelation of each element of C3 (A3)
if ~re_use
    p=parpool(kernels);
    tic
    parfor ii=1:9
        ii
        A3_Cross(:,:,ii) = Cross2SAR(C3(:,:,ii),def_azimuth,Nrg_lines_blk,y_step,def_sample,Range_block,x_step);
    end
    toc
    delete(p);
    
    
    A3_Cross_trace = A3_Cross(:,:,1) + A3_Cross(:,:,5) + A3_Cross(:,:,9);
    q_coff = (C3_Mean_trace+eps)./ (A3_Cross_trace+eps);
    
    save([Output_dir_path, 'A3_Cross.mat'], 'A3_Cross');
    save([Output_dir_path, 'q_coff.mat'], 'q_coff');
else
    load([Output_dir_path, 'A3_Cross.mat'], 'A3_Cross');
end

%% A3_Dop

% Calculate the autocorrelation of the k-vector
if ~re_use
    p=parpool(kernels);
    tic
    parfor ii=1:3
        ii
        K_Cross(:,:,ii) = Cross2SAR(K(:,:,ii),def_azimuth,Nrg_lines_blk,y_step,def_sample,Range_block,x_step);
    end
    toc
    delete(p);
    save([Output_dir_path, 'K_Cross.mat'], 'K_Cross');
else
    load([Output_dir_path, 'K_Cross.mat'], 'K_Cross');
end

% Generate A3_Dop Matrix
if ~re_use
    A3_Dop(:,:,1) = K_Cross(:,:,1).*conj(K_Cross(:,:,1));
    A3_Dop(:,:,2) = K_Cross(:,:,1).*conj(K_Cross(:,:,2));
    A3_Dop(:,:,3) = K_Cross(:,:,1).*conj(K_Cross(:,:,3));
    A3_Dop(:,:,4) = K_Cross(:,:,2).*conj(K_Cross(:,:,1));
    A3_Dop(:,:,5) = K_Cross(:,:,2).*conj(K_Cross(:,:,2));
    A3_Dop(:,:,6) = K_Cross(:,:,2).*conj(K_Cross(:,:,3));
    A3_Dop(:,:,7) = K_Cross(:,:,3).*conj(K_Cross(:,:,1));
    A3_Dop(:,:,8) = K_Cross(:,:,3).*conj(K_Cross(:,:,2));
    A3_Dop(:,:,9) = K_Cross(:,:,3).*conj(K_Cross(:,:,3));
    
    save([Output_dir_path, 'A3_Dop.mat'], 'A3_Dop');
else
    load([Output_dir_path, 'A3_Dop.mat'], 'A3_Dop');
end

%% A3_Cov
if ~re_use
    A3_Cov = A3_Cross - A3_Dop;
    save([Output_dir_path, 'A3_Cov.mat'], 'A3_Cov');
else
    load([Output_dir_path, 'A3_Cov.mat'], 'A3_Cov');
end

%% Output of ENVI format data
matrix_sign = ['11'; '12'; '13'; '21'; '22'; '23'; '31'; '32'; '33'];
for ii =1:length(matrix_sign)
    info = enviinfo(single(A3_Cross(:,:,ii)));
    enviwrite(single(A3_Cross(:,:,ii)), info, [Output_dir_path,'A3_',num2str(matrix_sign(ii,:)),'_Cross.bin']);
    clear info
    
    info = enviinfo(single(A3_Dop(:,:,ii)));
    enviwrite(single(A3_Dop(:,:,ii)), info, [Output_dir_path,'A3_',num2str(matrix_sign(ii,:)),'_Dop.bin']);
    clear info
    
    info = enviinfo(single(A3_Cov(:,:,ii)));
    enviwrite(single(A3_Cov(:,:,ii)), info, [Output_dir_path,'A3_',num2str(matrix_sign(ii,:)),'_Cov.bin']);
    clear info
    
    info = enviinfo(single(C3_Mean(:,:,ii)));
    enviwrite(single(C3_Mean(:,:,ii)), info, [Output_dir_path,'C3_',num2str(matrix_sign(ii,:)),'_Mean.bin']);
    clear info
end

info = enviinfo(single(q_coff));
enviwrite(single(q_coff), info, [Output_dir_path,'q_coff.bin']);
clear info