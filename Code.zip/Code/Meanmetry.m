function Mean_value = Meanmetry(k1_block,k2_block)
ph = mean(mean(k1_block.*conj(k2_block)));
Mean_value = ph;
end